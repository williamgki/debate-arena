import ClientPreview from './ClientPreview';

export const dynamic = 'force-dynamic';

export default function PreviewPage() {
  return <ClientPreview />;
}
