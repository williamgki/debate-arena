import DebateSessionClient from './DebateSessionClient';

export const dynamic = 'force-dynamic';

export default function Page() {
  return <DebateSessionClient />;
}
